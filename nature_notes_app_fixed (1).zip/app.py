import streamlit as st

st.set_page_config(page_title="Nature Notes Dashboard", layout="wide")

st.title("📝 Nature Notes: Headwaters eBird + Weather Dashboard")
st.markdown("This app is currently under construction. Please check back soon!")